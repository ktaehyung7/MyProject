
#compile
gcc -o ./game_of_life ./game_of_life.c

#excution
#./game_of_life
./game_of_life plus.txt
./game_of_life plus.txt 20
